#include <string>
#include <stdint.h>
#include <math.h>

int main() {
  uint64_t	blah = 0;
  size_t	blah2 = 1;
  std::string	blah3 = "3";
  
  return 0;
}
